Data from: Conservation and Convergence of Genetic Architecture in the Adaptive Radiation of Anolis Lizards

Joel W. McGlothlin, Megan E. Kobiela, Helen V. Wright, Jason J. Kolbe, Jonathan B. Losos, and Edmund D. Brodie III

ABSTRACT: The G matrix, which quantifies the genetic architecture of traits, is often viewed as an evolutionary constraint. However, G can evolve in response to selection and may also be viewed as a product of adaptive evolution. Convergent evolution of G in similar environments would suggest that G evolves adaptively, but it is difficult to disentangle such effects from phylogeny. Here, we use the adaptive radiation of Anolis lizards to ask whether convergence of G accompanies the repeated evolution of habitat specialists, or ecomorphs, across the Greater Antilles. We measured G in seven species representing three ecomorphs (trunk-crown, trunk-ground, and grass-bush). We found that the overall structure of G does not converge. Instead, the structure of G is well conserved and displays a phylogenetic signal consistent with Brownian motion. However, several elements of G showed signatures of convergence, indicating that some aspects of genetic architecture have been shaped by selection. Most notably, genetic correlations between limb traits and body traits were weaker in long-legged trunk-ground species, suggesting effects of recurrent selection on limb length. Our results demonstrate that common selection pressures may have subtle but consistent effects on the evolution of G, even as its overall structure remains conserved.

Keywords: adaptive radiation, Anolis lizards, constraint, G matrix, genetic correlation, quantitative genetics

National Science Foundation, Awards: DEB-0519658, DEB-0519777, DEB-0650078, DEB-0722475

This repository contains some data from a previous repository (https://datadryad.org/stash/dataset/doi:10.5061/dryad.pt2g084) along with code for performing the new analyses in the paper. We also include the raw X-ray images used to generate the results in the previous repository.

Description of files:

Data_and_Code.zip contains all the numerical data and code needed to generate the results in the paper. A .csv file is provided with descriptions of each individual file.

X-rays.zip contains the raw X-ray images used to generate the measurements in the previous repository. An .xlsx file with a key is provided to index the locations of each lizard.